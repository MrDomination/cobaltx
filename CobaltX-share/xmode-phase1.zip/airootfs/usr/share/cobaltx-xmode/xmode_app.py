"""X Mode - CobaltX's fullscreen handheld game launcher (Python side)."""
import faulthandler
import glob
import json
import os
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PyQt6.QtCore import (QObject, QSize, QTimer, QUrl, pyqtProperty,
                          pyqtSignal, pyqtSlot, qInstallMessageHandler)
from PyQt6.QtGui import QGuiApplication, QIcon, QPixmap
from PyQt6.QtQml import QQmlApplicationEngine
from PyQt6.QtQuick import QQuickImageProvider

import library
from gamepad import Gamepad
from sound import SoundPlayer

VERSION = "0.3"
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "cobaltx-xmode"
HISTORY_FILE = DATA_DIR / "history.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
PLAYS_FILE = DATA_DIR / "plays.json"
LOG_FILE = DATA_DIR / "xmode.log"
FREEZE_SECONDS = 8
LAUNCH_COOLDOWN = 3.0


class IconProvider(QQuickImageProvider):
    """image://icon/<name> -> icon from the current icon theme."""

    def __init__(self):
        super().__init__(QQuickImageProvider.ImageType.Pixmap)

    def requestPixmap(self, icon_id, requested_size):
        size = requested_size if requested_size.isValid() and requested_size.width() > 0 else QSize(256, 256)
        icon = QIcon.fromTheme(icon_id)
        pix = icon.pixmap(size) if not icon.isNull() else QPixmap()
        return pix, pix.size()


class Backend(QObject):
    gamesChanged = pyqtSignal()
    scanningChanged = pyqtSignal()
    batteryChanged = pyqtSignal()
    action = pyqtSignal(str)       # controller -> QML
    toast = pyqtSignal(str)
    launched = pyqtSignal()
    soundsChanged = pyqtSignal()
    inputChanged = pyqtSignal()
    _scanned = pyqtSignal(list)    # scanner thread -> main thread

    def __init__(self, fullscreen, in_session, sounds=None):
        super().__init__()
        self._sounds = sounds
        self._fullscreen = fullscreen
        self._in_session = in_session
        self._games = []
        self._launch = {}
        self._scanning = False
        self._battery = -1
        self._charging = False
        self._last_launch = 0.0
        self._history = self._load_json(HISTORY_FILE)
        self._plays = self._load_json(PLAYS_FILE)
        self._open = {}
        self._input = "keyboard"
        self._input_name = "Keyboard & Mouse"
        self._settings = {"sounds": True, **self._load_json(SETTINGS_FILE)}
        if self._sounds:
            self._sounds.enabled = self.soundsOn
        self._scanned.connect(self._on_scanned)
        self.updateBattery()

    # ------------------------------------------------------------ properties
    @pyqtProperty("QVariantList", notify=gamesChanged)
    def games(self):
        return self._games

    @pyqtProperty(bool, notify=scanningChanged)
    def scanning(self):
        return self._scanning

    @pyqtProperty(bool, constant=True)
    def fullscreen(self):
        return self._fullscreen

    @pyqtProperty(bool, constant=True)
    def inSession(self):
        return self._in_session

    @pyqtProperty(str, constant=True)
    def version(self):
        return VERSION

    @pyqtProperty(int, notify=batteryChanged)
    def battery(self):
        return self._battery

    @pyqtProperty(bool, notify=batteryChanged)
    def charging(self):
        return self._charging

    # ---------------------------------------------------------------- library
    @pyqtSlot()
    def refresh(self):
        if self._scanning:
            return
        self._scanning = True
        self.scanningChanged.emit()
        threading.Thread(target=lambda: self._scanned.emit(library.scan_all()), daemon=True).start()

    def _on_scanned(self, games):
        self._launch = {g["key"]: g.pop("launch") for g in games}
        self._open = {g["key"]: g.pop("open") for g in games}
        self._games = games
        self._apply_history()
        self._scanning = False
        self.scanningChanged.emit()

    def _apply_history(self):
        for g in self._games:
            # newest of: launched from X Mode, or played through Steam/Heroic directly
            g["lastPlayed"] = max(self._history.get(g["key"], 0), g.get("extLastPlayed", 0))
            g["plays"] = self._plays.get(g["key"], 0)
        self.gamesChanged.emit()

    @staticmethod
    def _load_json(path):
        try:
            data = json.loads(path.read_text())
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _save_json(path, data):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data))
        except Exception as e:
            print(f"[xmode] could not save {path.name}:", e)

    def _save_history(self):
        self._save_json(HISTORY_FILE, self._history)

    # ------------------------------------------------------- input method
    # Like Steam: whatever you touched last decides which button glyphs show.
    @pyqtProperty(str, notify=inputChanged)
    def inputMode(self):
        return self._input

    @pyqtProperty(str, notify=inputChanged)
    def inputName(self):
        return self._input_name

    def set_input(self, family, name):
        if (family, name) != (self._input, self._input_name):
            self._input, self._input_name = family, name
            self.inputChanged.emit()

    @pyqtSlot()
    def useKeyboard(self):
        self.set_input("keyboard", "Keyboard & Mouse")

    # ---------------------------------------------------------------- sounds
    @pyqtProperty(bool, notify=soundsChanged)
    def soundsOn(self):
        return bool(self._settings.get("sounds", True))

    @pyqtSlot()
    def toggleSounds(self):
        self._settings["sounds"] = not self.soundsOn
        self._save_json(SETTINGS_FILE, self._settings)
        if self._sounds:
            self._sounds.enabled = self.soundsOn
        self.soundsChanged.emit()

    @pyqtSlot(str)
    def playSound(self, name):
        if self._sounds:
            self._sounds.play(name)

    # ---------------------------------------------------------------- launch
    @pyqtSlot(str)
    def launch(self, key):
        now = time.monotonic()
        if now - self._last_launch < LAUNCH_COOLDOWN:
            return                                  # ignore double presses
        argv = self._launch.get(key)
        game = next((g for g in self._games if g["key"] == key), None)
        if not argv or not game:
            return
        self._last_launch = now
        try:
            subprocess.Popen(argv, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print("[xmode] launch failed:", argv, e)
            self.toast.emit(f"Couldn't start {game['title']}")
            return
        self.toast.emit(f"Launching {game['title']}…")
        self.launched.emit()
        self._history[key] = int(time.time())
        self._plays[key] = self._plays.get(key, 0) + 1
        self._save_history()
        self._save_json(PLAYS_FILE, self._plays)
        self._apply_history()

    @pyqtSlot(str)
    def openInLauncher(self, key):
        argv = self._open.get(key)
        if not argv:
            return
        try:
            subprocess.Popen(argv, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print("[xmode] open failed:", argv, e)

    # ------------------------------------------------------------------ menu
    @pyqtSlot(str)
    def menuAction(self, action):
        if action == "refresh":
            self.refresh()
            self.toast.emit("Refreshing library…")
        elif action == "desktop":
            if self._in_session and shutil.which("cobaltx-session-select"):
                subprocess.Popen(["cobaltx-session-select", "desktop"], start_new_session=True)
            else:
                QGuiApplication.quit()
        elif action in ("suspend", "reboot", "poweroff"):
            subprocess.Popen(["systemctl", action], start_new_session=True)

    # --------------------------------------------------------------- battery
    @pyqtSlot()
    def updateBattery(self):
        level, charging = -1, False
        for bat in sorted(glob.glob("/sys/class/power_supply/BAT*")):
            try:
                level = int(Path(bat, "capacity").read_text().strip())
                charging = Path(bat, "status").read_text().strip() in ("Charging", "Full")
                break
            except Exception:
                continue
        if (level, charging) != (self._battery, self._charging):
            self._battery, self._charging = level, charging
            self.batteryChanged.emit()

    # ------------------------------------------------------------ controller
    def on_pad(self, name):
        # Only react while X Mode itself is focused - otherwise pressing A
        # inside a game would launch another game behind it.
        if QGuiApplication.focusWindow() is not None:
            self.action.emit(name)


def _open_log():
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        # keep the log small: start fresh when it grows past 1 MB
        mode = "w" if LOG_FILE.exists() and LOG_FILE.stat().st_size > 1_000_000 else "a"
        return open(LOG_FILE, mode, buffering=1)
    except Exception:
        return None


def _fd_table():
    rows = []
    for fd in sorted(os.listdir("/proc/self/fd"), key=int):
        try:
            rows.append(f"    fd {fd}: {os.readlink('/proc/self/fd/' + fd)}")
        except OSError:
            pass
    return "\n".join(rows)


def _install_qt_log(log):
    """Send Qt's warnings to our log file instead of the terminal.

    A Qt warning written to a blocked terminal froze the whole UI once, so
    X Mode never writes Qt messages to stderr. Repeats are counted, not spammed."""
    seen = {}

    def handler(_mode, _ctx, msg):
        n = seen.get(msg, 0) + 1
        seen[msg] = n
        if n > 3 and n not in (10, 100, 1000, 10000):
            return
        line = f"{time.strftime('%H:%M:%S')} [qt] {msg}" + (f"  (x{n})" if n > 1 else "")
        m = re.search(r"Invalid socket (\d+)", msg)
        if m and n == 1:                 # record what that file descriptor was
            try:
                line += f"\n    -> fd {m.group(1)} is now: {os.readlink('/proc/self/fd/' + m.group(1))}"
            except OSError:
                line += f"\n    -> fd {m.group(1)} was already closed"
            line += "\n  open files at that moment:\n" + _fd_table()
        try:
            log.write(line + "\n")
        except Exception:
            pass

    qInstallMessageHandler(handler)


def _start_freeze_recorder(app, log):
    """If the interface stops responding for FREEZE_SECONDS, write what every
    thread was doing to ~/.local/share/cobaltx-xmode/xmode.log."""
    if log is None:
        return
    log.write(f"\n=== X Mode {VERSION} started {time.ctime()} ===\n")
    faulthandler.enable(log)

    def heartbeat():
        faulthandler.cancel_dump_traceback_later()
        faulthandler.dump_traceback_later(FREEZE_SECONDS, repeat=False, file=log)

    timer = QTimer(app)
    timer.timeout.connect(heartbeat)
    timer.start(1000)
    heartbeat()
    app._freeze_log = (log, timer)        # keep alive


def main(share_dir):
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Basic")
    signal.signal(signal.SIGINT, signal.SIG_DFL)     # Ctrl+C in a terminal really quits
    args = sys.argv[1:]
    in_session = os.environ.get("XMODE_SESSION") == "1"
    # Fullscreen by default (it's a console-style UI). --windowed for development.
    fullscreen = "--windowed" not in args

    log = _open_log()
    if log is not None:
        _install_qt_log(log)
        sys.stdout = sys.stderr = log    # our own prints go to the log too
    app = QGuiApplication(sys.argv)
    app.setApplicationName("X Mode")
    app.setOrganizationName("CobaltX")
    app.setDesktopFileName("cobaltx-xmode")

    _start_freeze_recorder(app, log)
    sounds = SoundPlayer(Path(share_dir) / "sounds")
    backend = Backend(fullscreen, in_session, sounds)
    backend.playSound("startup")
    pad = Gamepad(app)
    pad.action.connect(backend.on_pad)
    pad.device.connect(backend.set_input)

    engine = QQmlApplicationEngine()
    engine.addImageProvider("icon", IconProvider())
    engine.rootContext().setContextProperty("backend", backend)
    engine.load(QUrl.fromLocalFile(str(Path(share_dir) / "Main.qml")))
    if not engine.rootObjects():
        print("[xmode] failed to load the interface")
        return 1

    backend.refresh()
    return app.exec()
