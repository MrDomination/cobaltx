"""Window control for X Mode (KWin).

- A small KWin script reports every open app window to X Mode over D-Bus, so
  X Mode knows what is running (task view, plain background behind apps).
- One-shot KWin scripts bring a window to the front, close it, or bring X Mode
  itself back (the Guide/PS button).
- Games launched from X Mode are made fullscreen (tools and launchers are not).

All KWin calls go through gdbus in one background thread, so the UI never
waits on them. Under gamescope none of this applies (gamescope manages focus).
"""
import json
import os
import queue
import subprocess
import threading
from pathlib import Path

from PyQt6.QtCore import QObject, pyqtClassInfo, pyqtSignal, pyqtSlot

SERVICE = "org.cobaltx.XMode"
PATH = "/XMode"
IFACE = "org.cobaltx.XMode"

TRACKER = "cobaltx-xmode-tracker"
ACTION = "cobaltx-xmode-action"
FULLSCREEN = "cobaltx-xmode-fullscreen"
FULLSCREEN_SECONDS = 120

# Windows that are never "apps" in the task view
IGNORED = ["cobaltx-xmode", "plasmashell", "org.kde.plasmashell", "krunner",
           "org.kde.krunner", "xdg-desktop-portal-kde", "kwin_wayland",
           "org.kde.polkit-kde-authentication-agent-1", "polkit-kde-authentication-agent-1"]

# Never forced fullscreen (launcher clients, login windows, ...)
NO_FULLSCREEN = IGNORED + ["steam", "steamwebhelper", "heroic", "com.heroicgameslauncher.hgl",
                           "com.usebottles.bottles", "bottles", "net.lutris.lutris", "lutris"]

_JS_FIND = """
function findWindow(id) {
    var list = workspace.windowList();
    for (var i = 0; i < list.length; i++) {
        if (String(list[i].internalId) === id) return list[i];
    }
    return null;
}
"""

TRACKER_JS = """
// CobaltX X Mode: tell X Mode which app windows are open
const ignored = %(ignored)s;
function report() {
    var out = [];
    var wins = workspace.stackingOrder;          // bottom -> top
    for (var i = 0; i < wins.length; i++) {
        var w = wins[i];
        if (!w || !w.normalWindow || w.skipTaskbar) continue;
        var cls = String(w.resourceClass || "").toLowerCase();
        if (ignored.indexOf(cls) >= 0) continue;
        out.push({ id: String(w.internalId), title: String(w.caption || cls), cls: cls,
                   active: w === workspace.activeWindow });
    }
    callDBus("%(service)s", "%(path)s", "%(iface)s", "setWindows", JSON.stringify(out));
}
workspace.windowAdded.connect(function (w) {
    if (w && w.captionChanged) w.captionChanged.connect(report);
    report();
});
workspace.windowRemoved.connect(report);
workspace.windowActivated.connect(report);
report();
"""

FULLSCREEN_JS = """
// CobaltX X Mode: fullscreen the windows of a game launched from X Mode
const skip = %(skip)s;
workspace.windowAdded.connect(function (w) {
    if (!w || !w.normalWindow) return;
    var cls = String(w.resourceClass || "").toLowerCase();
    if (skip.indexOf(cls) >= 0) return;
    w.fullScreen = true;
});
"""


def under_gamescope():
    return ("gamescope" in os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
            or bool(os.environ.get("GAMESCOPE_WAYLAND_DISPLAY")))


def _js_str(s):
    return json.dumps(str(s))


@pyqtClassInfo("D-Bus Interface", IFACE)
class _BusObject(QObject):
    """Receives the window list from the KWin tracker script."""
    received = pyqtSignal(list)

    @pyqtSlot(str)
    def setWindows(self, payload):
        try:
            data = json.loads(payload)
            if isinstance(data, list):
                self.received.emit(data)
        except ValueError:
            pass


class WindowManager(QObject):
    windowsChanged = pyqtSignal(list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.enabled = not under_gamescope()
        self.windows = []
        self._queue = queue.Queue()
        self._fs_generation = 0
        runtime = Path(os.environ.get("XDG_RUNTIME_DIR") or "/tmp")
        self._dir = runtime / "cobaltx-xmode"
        self._bus = None
        if not self.enabled:
            return
        try:
            self._dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            self.enabled = False
            return
        threading.Thread(target=self._worker, name="xmode-kwin", daemon=True).start()
        self._register_bus()
        self._load(TRACKER, TRACKER_JS % {"ignored": json.dumps(IGNORED), "service": SERVICE,
                                          "path": PATH, "iface": IFACE})

    # -------------------------------------------------------------- D-Bus
    def _register_bus(self):
        try:
            from PyQt6.QtDBus import QDBusConnection
        except ImportError:
            print("[xmode] QtDBus not available - task view disabled")
            return
        bus = QDBusConnection.sessionBus()
        if not bus.isConnected():
            print("[xmode] no session D-Bus - task view disabled")
            return
        self._bus = _BusObject(self)
        self._bus.received.connect(self._on_windows)
        bus.registerService(SERVICE)
        bus.registerObject(PATH, self._bus, QDBusConnection.RegisterOption.ExportAllSlots)

    def _on_windows(self, windows):
        self.windows = windows
        self.windowsChanged.emit(windows)

    # --------------------------------------------------------- KWin calls
    def _worker(self):
        while True:
            fn = self._queue.get()
            try:
                fn()
            except Exception as e:
                print("[xmode] kwin call failed:", e)

    @staticmethod
    def _gdbus(method, *args):
        subprocess.run(["gdbus", "call", "--session", "--dest", "org.kde.KWin",
                        "--object-path", "/Scripting", "--method",
                        f"org.kde.kwin.Scripting.{method}", *args],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)

    def _load(self, name, code):
        def job():
            path = self._dir / f"{name}.js"
            path.write_text(code)
            self._gdbus("unloadScript", name)
            self._gdbus("loadScript", str(path), name)
            self._gdbus("start")
        self._queue.put(job)

    def _unload(self, name):
        self._queue.put(lambda: self._gdbus("unloadScript", name))

    def _action(self, body):
        if self.enabled:
            self._load(ACTION, _JS_FIND + body)

    # ------------------------------------------------------------ actions
    def activate(self, window_id):
        self._action(f"""
var w = findWindow({_js_str(window_id)});
if (w) {{ w.minimized = false; workspace.activeWindow = w; }}
""")

    def close(self, window_id):
        self._action(f"""
var w = findWindow({_js_str(window_id)});
if (w) w.closeWindow();
""")

    def raise_xmode(self):
        self._action("""
var list = workspace.windowList();
for (var i = 0; i < list.length; i++) {
    if (String(list[i].resourceClass).toLowerCase() === "cobaltx-xmode") {
        list[i].minimized = false; workspace.activeWindow = list[i]; break;
    }
}
""")

    def game_launched(self, fullscreen):
        """Call right after starting something. fullscreen=False for tools/launchers."""
        if not self.enabled or not fullscreen:
            return
        self._fs_generation += 1
        gen = self._fs_generation
        self._load(FULLSCREEN, FULLSCREEN_JS % {"skip": json.dumps(NO_FULLSCREEN)})

        def stop():
            if gen == self._fs_generation:
                self._unload(FULLSCREEN)
        t = threading.Timer(FULLSCREEN_SECONDS, stop)
        t.daemon = True
        t.start()

    def shutdown(self):
        if self.enabled:
            for name in (TRACKER, FULLSCREEN, ACTION):
                try:
                    self._gdbus("unloadScript", name)
                except Exception:
                    pass
