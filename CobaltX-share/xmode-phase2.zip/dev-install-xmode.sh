#!/bin/bash
# Installs X Mode from the build tree onto THIS machine (Domin) for testing,
# without building an ISO:  sudo bash ~/cobaltx/dev-install-xmode.sh
set -e
R="${COBALTX_DIR:-/home/${SUDO_USER:-$USER}/cobaltx}/airootfs"
[ "$(id -u)" = 0 ] || { echo "run with sudo"; exit 1; }

install -Dm755 "$R/usr/local/bin/cobaltx-xmode"                 /usr/local/bin/cobaltx-xmode
install -Dm755 "$R/usr/local/bin/cobaltx-xmode-session"         /usr/local/bin/cobaltx-xmode-session
install -Dm755 "$R/usr/local/bin/cobaltx-session-select"        /usr/local/bin/cobaltx-session-select
install -Dm755 "$R/usr/local/bin/cobaltx-xmode-installer-setup" /usr/local/bin/cobaltx-xmode-installer-setup
install -Dm755 "$R/usr/local/lib/cobaltx/session-helper"        /usr/local/lib/cobaltx/session-helper
rm -rf /usr/share/cobaltx-xmode
cp -r "$R/usr/share/cobaltx-xmode" /usr/share/cobaltx-xmode
install -Dm644 "$R/usr/share/wayland-sessions/cobaltx-xmode.desktop"   /usr/share/wayland-sessions/cobaltx-xmode.desktop
install -Dm644 "$R/usr/share/applications/cobaltx-xmode.desktop"       /usr/share/applications/cobaltx-xmode.desktop
install -Dm644 "$R/usr/share/applications/cobaltx-xmode-switch.desktop" /usr/share/applications/cobaltx-xmode-switch.desktop
install -Dm644 "$R/etc/xdg/autostart/cobaltx-session-consume.desktop"  /etc/xdg/autostart/cobaltx-session-consume.desktop
install -Dm644 "$R/usr/share/polkit-1/actions/org.cobaltx.session.policy" /usr/share/polkit-1/actions/org.cobaltx.session.policy

pacman -Syu --needed --noconfirm libpulse gamescope sdl2-compat python-yaml qt6-declarative qt6-svg python-pyqt6 >/dev/null \
    || echo "! package install failed - run: sudo pacman -Syu"
echo "✓ X Mode installed on this system."
echo "  Test: app menu -> 'Switch to X Mode'  (or log out and pick 'CobaltX X Mode' on the login screen)"
echo "  In a VM gamescope can't start, so the session falls back to KWin automatically."
